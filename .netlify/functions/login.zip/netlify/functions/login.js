const fs = require('fs').promises;
const path = require('path');
const jwt = require('jsonwebtoken');

const professionalsPath = path.resolve(__dirname, '../../db/professionals.json');
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';

const getProfessionals = async () => {
    try {
        const data = await fs.readFile(professionalsPath, 'utf-8');
        return JSON.parse(data);
    } catch (error) {
        if (error.code === 'ENOENT') return [];
        throw error;
    }
};

exports.handler = async function(event, context) {
    if (event.httpMethod !== 'POST') {
        return { statusCode: 405, body: 'Method Not Allowed' };
    }

    const { email, password } = JSON.parse(event.body);

    // Admin login
    if (email === 'admin@reabilite.pro' && password === 'admin123') {
        const token = jwt.sign({ type: 'admin' }, JWT_SECRET, { expiresIn: '8h' });
        return { statusCode: 200, body: JSON.stringify({ accessToken: token, userType: 'admin' }) };
    }

    // Professional login
    try {
        const professionals = await getProfessionals();
        const professional = professionals.find(p => p.email === email && p.password === password);

        if (!professional) {
            return { statusCode: 401, body: JSON.stringify({ message: 'Email ou senha inválidos.' }) };
        }

        if (professional.registrationStatus !== 'Aprovado') {
            return { statusCode: 403, body: JSON.stringify({ message: `Sua conta está ${professional.registrationStatus.toLowerCase()}.` }) };
        }

        const token = jwt.sign({ id: professional.id, type: 'professional' }, JWT_SECRET, { expiresIn: '8h' });
        return { statusCode: 200, body: JSON.stringify({ accessToken: token, userType: 'professional' }) };

    } catch (error) {
        console.error(error);
        return { statusCode: 500, body: JSON.stringify({ message: 'Erro interno do servidor' }) };
    }
};