const fs = require('fs').promises;
const path = require('path');

const tokensPath = path.resolve(__dirname, '../../db/invitation-tokens.json');
const patientsPath = path.resolve(__dirname, '../../db/patients.json');

// Funções auxiliares para ler/salvar dados
const readData = async (filePath) => {
    try {
        const data = await fs.readFile(filePath, 'utf-8');
        return JSON.parse(data);
    } catch (error) {
        if (error.code === 'ENOENT') return [];
        throw error;
    }
};

const writeData = async (filePath, data) => {
    await fs.writeFile(filePath, JSON.stringify(data, null, 2));
};

exports.handler = async function(event, context) {
    if (event.httpMethod !== 'POST') {
        return { statusCode: 405, body: JSON.stringify({ message: 'Method Not Allowed' }) };
    }

    const { token, ...patientData } = JSON.parse(event.body);

    if (!token) {
        return { statusCode: 400, body: JSON.stringify({ message: 'Token de convite é obrigatório.' }) };
    }

    try {
        const tokens = await readData(tokensPath);
        const tokenIndex = tokens.findIndex(t => t.token === token);
        const invitation = tokens[tokenIndex];

        if (!invitation || invitation.used || invitation.expires < Date.now()) {
            return { statusCode: 400, body: JSON.stringify({ message: 'Token de convite inválido, expirado ou já utilizado.' }) };
        }

        // Marcar token como usado
        tokens[tokenIndex].used = true;
        await writeData(tokensPath, tokens);

        // Criar o novo paciente
        const patients = await readData(patientsPath);
        const newPatient = {
            id: Date.now(),
            professionalId: invitation.professionalId,
            ...patientData
        };
        
        patients.push(newPatient);
        await writeData(patientsPath, patients);

        return {
            statusCode: 201,
            body: JSON.stringify({ message: 'Paciente cadastrado com sucesso!', patient: newPatient })
        };

    } catch (error) {
        console.error('Erro ao registrar paciente:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Erro interno do servidor.' })
        };
    }
};